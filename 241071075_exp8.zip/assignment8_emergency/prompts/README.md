# AI prompt log — fill with genuine records

For every track create a subfolder and include:
- original prompt (verbatim)
- AI response or relevant excerpt
- revised prompt(s)
- resulting code change and commit URL
- verification note and test output
- screenshots/chat export from each AI tool

Also add `AI_TOOLS_REGISTER.md` listing actual tool/model version, dates, tracks and purpose. Do not invent usage history.
