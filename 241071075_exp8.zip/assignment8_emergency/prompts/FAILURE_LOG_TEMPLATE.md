# AI-generated failure log (record only genuine cases)

For each of at least three real failures:
1. Track and date:
2. Prompt:
3. Incorrect/unsafe/inefficient output:
4. How it was detected:
5. Fix made:
6. Verification evidence:
7. Lesson learned:
